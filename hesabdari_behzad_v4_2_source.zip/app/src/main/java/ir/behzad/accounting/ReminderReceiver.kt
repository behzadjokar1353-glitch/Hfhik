package ir.behzad.accounting

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import org.json.JSONArray

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("behzad_data", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("notifications_enabled", true)) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "behzad_due_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "یادآورهای حسابداری بهزاد", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val debts = try { JSONArray(prefs.getString("debts", "[]")) } catch (_: Exception) { JSONArray() }
        val target = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 3) }
        val targetDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(target.time)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (!prefs.getBoolean("receivable_payable_reminders", true)) return
        for (i in 0 until debts.length()) {
            val debt = debts.optJSONObject(i) ?: continue
            if (debt.optString("status") == "تسویه‌شده" || debt.optString("dueDate") != targetDate) continue
            val key = "reminded_${i}_${targetDate}"
            if (prefs.getBoolean(key, false)) continue
            val title = "سررسید نزدیک است: ${debt.optString("kind", "بدهی/طلب")}"
            val body = "${debt.optString("person")} — ${debt.optString("title")} — مبلغ ${debt.optLong("amount")}، سررسید $targetDate"
            val open = PendingIntent.getActivity(context, 9202, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(context, channelId).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setStyle(Notification.BigTextStyle().bigText(body)).setContentIntent(open).setAutoCancel(true).build()
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(context).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setStyle(Notification.BigTextStyle().bigText(body)).setContentIntent(open).setAutoCancel(true).build()
            }
            try { manager.notify((debt.optString("person") + targetDate + i).hashCode(), notification); prefs.edit().putBoolean(key, true).apply() } catch (_: SecurityException) { }
        }
    }
}
